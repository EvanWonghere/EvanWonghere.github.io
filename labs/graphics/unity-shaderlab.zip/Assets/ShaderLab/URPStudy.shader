// Original ConceptLab URP17 lesson: main directional light, matching alpha-test passes.
Shader "ConceptLab/URPStudy" {
 Properties { _BaseColor("Color",Color)=(0.2,0.7,0.55,1) _MainTex("Checker",2D)="white"{} _Amount("Dissolve threshold",Range(0,1))=0.35 }
 SubShader {
  Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
  HLSLINCLUDE
  #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
  #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
  TEXTURE2D(_MainTex); SAMPLER(sampler_MainTex);
  CBUFFER_START(UnityPerMaterial)
  float4 _BaseColor; float4 _MainTex_ST; float _Amount;
  CBUFFER_END
  struct Attributes { float4 positionOS:POSITION; float3 normalOS:NORMAL; float2 uv:TEXCOORD0; };
  struct Varyings { float4 positionCS:SV_POSITION; float2 uv:TEXCOORD0; float3 normalWS:TEXCOORD1; float3 positionWS:TEXCOORD2; };
  float random2(float2 p){return frac(sin(dot(p,float2(127.1,311.7)))*43758.5453);}
  float noise2(float2 p){float2 i=floor(p),f=frac(p);f=f*f*(3-2*f);return lerp(lerp(random2(i),random2(i+float2(1,0)),f.x),lerp(random2(i+float2(0,1)),random2(i+float2(1,1)),f.x),f.y);}
  float fbm(float2 p){float n=0,a=.5;[unroll]for(int i=0;i<4;i++){n+=a*noise2(p);p=p*2+3.7;a*=.5;}return n;}
  void ClipMaterial(float2 uv){clip(fbm(uv*7)-_Amount);}
  Varyings vert(Attributes input){
   Varyings o;o.positionWS=TransformObjectToWorld(input.positionOS.xyz);o.normalWS=TransformObjectToWorldNormal(input.normalOS);
   o.positionCS=TransformWorldToHClip(o.positionWS);o.uv=TRANSFORM_TEX(input.uv,_MainTex);return o;
  }
  half4 depthFrag(Varyings input):SV_Target{ClipMaterial(input.uv);return 0;}
  ENDHLSL
  Pass {
   Name "Forward" Tags { "LightMode"="UniversalForward" }
   ZWrite On Cull Back
   HLSLPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
   #pragma multi_compile_fragment _ _SHADOWS_SOFT
   half4 frag(Varyings input):SV_Target {
    ClipMaterial(input.uv);
    #if defined(_MAIN_LIGHT_SHADOWS_SCREEN)
     float4 shadowCoord=ComputeScreenPos(TransformWorldToHClip(input.positionWS));
    #else
     float4 shadowCoord=TransformWorldToShadowCoord(input.positionWS);
    #endif
    Light mainLight=GetMainLight(shadowCoord);
    half diffuse=saturate(dot(normalize(input.normalWS),mainLight.direction));
    half3 base=SAMPLE_TEXTURE2D(_MainTex,sampler_MainTex,input.uv).rgb*_BaseColor.rgb;
    return half4(base*(.12+.88*diffuse*mainLight.color*mainLight.distanceAttenuation*mainLight.shadowAttenuation),1);
   }
   ENDHLSL
  }
  Pass {
   Name "ShadowCaster" Tags { "LightMode"="ShadowCaster" }
   ZWrite On ZTest LEqual ColorMask 0 Cull Back
   HLSLPROGRAM
   #pragma vertex shadowVert
   #pragma fragment depthFrag
   #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
   float3 _LightDirection; float3 _LightPosition;
   Varyings shadowVert(Attributes input) {
    Varyings o=vert(input);
    #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
     float3 direction=normalize(_LightPosition-o.positionWS);
    #else
     float3 direction=_LightDirection;
    #endif
    o.positionCS=TransformWorldToHClip(ApplyShadowBias(o.positionWS,o.normalWS,direction));
    #if UNITY_REVERSED_Z
     o.positionCS.z=min(o.positionCS.z,UNITY_NEAR_CLIP_VALUE*o.positionCS.w);
    #else
     o.positionCS.z=max(o.positionCS.z,UNITY_NEAR_CLIP_VALUE*o.positionCS.w);
    #endif
    return o;
   }
   ENDHLSL
  }
  Pass {
   Name "DepthOnly" Tags { "LightMode"="DepthOnly" }
   ZWrite On ColorMask 0 Cull Back
   HLSLPROGRAM
   #pragma vertex vert
   #pragma fragment depthFrag
   ENDHLSL
  }
 }
}

#if UNITY_EDITOR
using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering.Universal;
namespace ConceptLab.Graphics {
    public static class GraphicsLabSetup {
        [MenuItem("ConceptLab/Create ShaderLab Scene")]
        public static void CreateScene() {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GameObject controller = new GameObject("ShaderLab controls");
            var lab = controller.AddComponent<GraphicsShaderLab>(); lab.examples = new Renderer[3];
            for (int i = 0; i < 3; i++) {
                GameObject mesh = GameObject.CreatePrimitive(i == 0 ? PrimitiveType.Quad : PrimitiveType.Sphere);
                mesh.name = new[] { "UV and texture", "Vertex wave", "Dissolve" }[i];
                mesh.transform.position = new Vector3((i - 1) * 2.1f, 0, 0); lab.examples[i] = mesh.GetComponent<Renderer>();
            }
            var camera = new GameObject("Camera").AddComponent<Camera>(); camera.transform.position = new Vector3(0, 0, -6); camera.transform.LookAt(Vector3.zero); camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.035f,.075f,.1f);
            camera.gameObject.AddComponent<UniversalAdditionalCameraData>();
            EditorSceneManager.SaveScene(camera.gameObject.scene, "Assets/ShaderLab/ShaderLabScene.unity");
            AssetDatabase.Refresh();
        }
        // Batchmode import/compiler evidence only; does not replace human Play review.
        public static void Verify() {
            string[] names = { "UVTexture", "VertexWave", "Dissolve", "DissolveExercise" };
            foreach (string name in names) {
                Shader shader = AssetDatabase.LoadAssetAtPath<Shader>("Assets/ShaderLab/" + name + ".shader");
                if (shader == null || ShaderUtil.ShaderHasError(shader)) throw new Exception("Shader import failed: " + name);
                Debug.Log("ShaderLab imported: " + name);
            }
            CreateScene();
            Debug.Log("ShaderLab import/compiler check complete; Play visuals require manual acceptance.");
        }
    }
}
#endif

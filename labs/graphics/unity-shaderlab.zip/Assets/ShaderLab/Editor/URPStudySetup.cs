#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering.Universal;
namespace ConceptLab.Graphics {
    public static class URPStudySetup {
        [MenuItem("ConceptLab/Create URP Study Scene")]
        public static void CreateScene() {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            Shader shader = Shader.Find("ConceptLab/URPStudy");
            if (shader == null || ShaderUtil.ShaderHasError(shader)) throw new Exception("URPStudy shader import failed");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            Material Make(string name, float amount) {
                string path = "Assets/ShaderLab/" + name + ".mat";
                Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
                if (material == null) { material = new Material(shader); AssetDatabase.CreateAsset(material, path); }
                material.SetFloat("_Amount", amount); return material;
            }
            var cast = Make("URPStudyCast", .35f); var receive = Make("URPStudyReceive", 0);
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube); cube.name = "Alpha-test caster"; cube.transform.localScale = Vector3.one * 1.3f; cube.GetComponent<Renderer>().sharedMaterial = cast;
            var floor = GameObject.CreatePrimitive(PrimitiveType.Plane); floor.name = "Main light shadow receiver"; floor.transform.position = new Vector3(0,-.7f,0); floor.GetComponent<Renderer>().sharedMaterial = receive;
            var light = new GameObject("Main directional light").AddComponent<Light>(); light.type = LightType.Directional; light.intensity = 1.2f; light.shadows = LightShadows.Hard; light.transform.rotation = Quaternion.Euler(50,-35,0); light.gameObject.AddComponent<UniversalAdditionalLightData>(); RenderSettings.sun = light;
            var camera = new GameObject("Camera").AddComponent<Camera>(); camera.transform.position = new Vector3(3,2.4f,-4.5f); camera.transform.LookAt(Vector3.zero); camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.035f,.075f,.1f); camera.gameObject.AddComponent<UniversalAdditionalCameraData>();
            var controls = new GameObject("URP lesson controls").AddComponent<URPStudyControls>(); controls.material = cast; controls.mainLight = light;
            EditorSceneManager.SaveScene(camera.gameObject.scene,"Assets/ShaderLab/URPStudyScene.unity"); AssetDatabase.SaveAssets();
        }
    }
}
#endif

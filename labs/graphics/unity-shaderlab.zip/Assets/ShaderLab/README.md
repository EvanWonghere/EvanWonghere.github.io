# ShaderLab Unity 对照

目标环境：Unity 6000.0.28f1 / URP 17.0.1。网页运行 GLSL；这里运行 Unity ShaderLab 外壳中的 HLSL。二者不是同一个编译器。

1. 导入 `Assets/ShaderLab/`，保持工程原有 Unity / URP 版本。
2. 确认 Universal Renderer 的 Depth Priming 为 Disabled；本课材质没有 DepthOnly pass。
3. 选择菜单 `ConceptLab/Create ShaderLab Scene`，保存现有场景后创建新场景，再进入 Play。
4. 左侧 UV/纹理，中间顶点波动，右侧噪声溶解。取消 Animate，固定 Time 与 Amount，保存截图和环境，再在网页记录解释。
5. 将右侧材质换为 `DissolveExercise`，补齐 `clip(noise-threshold)`；参考实现独立保留。

`TEXTURE2D` / `SAMPLE_TEXTURE2D` 对应 GLSL sampler2D / texture；`TransformObjectToHClip` 对应 P*V*M；HLSL 用 `lerp` / `frac`。纹理 sRGB 标记和项目颜色空间由 Unity 负责，勿再机械地做重复解码。

所有素材为运行时程序化棋盘格和 Unity 原始几何体。固定方向光为教学公式，不调用 URP 主灯光。顶点形变后法线未重建；溶解示例不含 ShadowCaster / DepthOnly pass，不是完整生产材质。帧调试、轮廓、采样和画面质量需要实际 Play 模式核对。

可用 `-batchmode -projectPath <工程> -executeMethod ConceptLab.Graphics.GraphicsLabSetup.Verify -quit` 检查导入与编译；成功不替代 Play 模式评审。

## URP 实战：实际主光源

选择 `ConceptLab/Create URP Study Scene` 创建额外场景（先保存当前场景），使用 `URPStudy.shader`、方向主光、投影立方体和接收平面。URP Asset 要开启 Main Light Shadows，保持 Depth Priming Disabled。它有 Forward、ShadowCaster、DepthOnly 三个基础 Pass；三者调用相同的噪声裁剪函数。Play 中可改变阈值和主光阴影开关。材质编辑会保存在本机工程，发布包不包含生成的场景、材质或捕帧。

1. 固定阈值与相机，在 Frame Debugger 找主光 shadow map 和 opaque 绘制；记下实际事件名称、材质和 Pass，不根据名称猜测已绘制。
2. 旋转真实主光，保存亮度与阴影改变的画面。网页固定 GLSL 光源只能做公式对照，不能验证 URP。
3. 在 Forward 中暂时移除 shadowAttenuation，比较接收面；恢复后在 ShadowCaster 暂时移除 ClipMaterial，检查本体/影子不一致。
4. 保存失败和修复两套源码、参数、Unity/URP 版本与 Frame Debugger 证据。自动 smoke 只验证运行、基础 Pass 与阴影开关图像差异，不代替人工评审。

此例为基础 opaque/alpha-test Lambert，没有附加灯、GI、Meta、DepthNormals、完整 PBR 或形变法线；不要直接视为 URP Lit 的替代。

## 逐课迁移检查表

| 网页课 | Unity 自己的练习与核对 |
|---|---|
| UV/uniform | 在 UVTexture 中实现一个反向通道；区分材质值与每帧参数 |
| SDF/图案 | 在片元加入圆/环和重复；用 ddx/ddy/fwidth 检查缩放，注意 HLSL mul 约定 |
| 纹理/颜色 | 核对贴图 sRGB、项目 Linear；分别改变过滤和亮度，防止双重解码 |
| noise/fBM | 逐层重建 noise/fBM，固定 LabTime；跨 GPU hash 不保证逐像素一致 |
| 顶点/光照 | 用 VertexWave，再自行重建形变法线；使用同空间 N/L/V |
| 溶解 | 用 DissolveExercise 完成 clip；早期示例的阴影 Pass 缺失是限制 |
| 法线贴图 | 自行在 URPStudy 添加 tangent 输入和 TBN；法线纹理按 Normal map/data 导入；核对镜像 UV 手性 |
| 透明 | 自行创建透明材质；匹配 Blend SrcAlpha OneMinusSrcAlpha 或 Blend One OneMinusSrcAlpha 与预乘源码；研究 ZWrite Off 和排序 |
| 后处理/多 Pass | 用目标 URP17 的 RenderGraph Renderer Feature 创建独立读写目标，先 copy，再横向/纵向滤波；不要把浏览器 FBO API 直接复制到 Unity |
| PBR 入门 | 在 URP Lit 材质中对照 roughness/smoothness 与 metallic；网页 GGX 公式只覆盖简化直接光，另核对引擎 IBL/GI |
| URP 实战 | 运行新场景，完成前述主光、clip、ShadowCaster/DepthOnly 与实际捕帧检查 |

后三类迁移是明确的独立练习，并非下载包已经提供完整法线/透明/RenderGraph/PBR 材质实现。优先参考目标版本官方文档：

- [主光阴影方法](https://docs.unity3d.com/6000.0/Documentation/Manual/urp/use-built-in-shader-methods-shadows.html)
- [URP 自定义 Shader](https://docs.unity3d.com/6000.0/Documentation/Manual/urp/writing-custom-shaders-urp.html)

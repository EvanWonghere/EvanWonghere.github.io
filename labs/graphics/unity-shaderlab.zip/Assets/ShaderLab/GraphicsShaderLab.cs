using UnityEngine;
namespace ConceptLab.Graphics {
    // Teaching scene only. Owns its generated materials and texture.
    public sealed class GraphicsShaderLab : MonoBehaviour {
        public Renderer[] examples;
        float amount = .4f, fixedTime;
        bool animate, texture;
        Texture2D checker;
        Material[] materials;
        void Start() {
            checker = new Texture2D(32, 32, TextureFormat.RGBA32, false, false) { name = "ConceptLab procedural checker", wrapMode = TextureWrapMode.Repeat };
            for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++) checker.SetPixel(x, y, ((x / 4 + y / 4) % 2 == 0) ? new Color(.12f,.7f,.62f) : new Color(.95f,.72f,.35f));
            checker.Apply();
            string[] shaders = { "ConceptLab/UVTexture", "ConceptLab/VertexWave", "ConceptLab/Dissolve" };
            materials = new Material[examples.Length];
            for (int i = 0; i < examples.Length; i++) {
                Shader shader = Shader.Find(shaders[i % shaders.Length]);
                if (shader == null) { Debug.LogError("Missing teaching shader: " + shaders[i % shaders.Length]); continue; }
                materials[i] = new Material(shader); materials[i].SetTexture("_MainTex", checker); examples[i].sharedMaterial = materials[i];
            }
        }
        void Update() {
            if (materials == null) return;
            foreach (Material material in materials) if (material != null) {
                material.SetFloat("_Amount", amount); material.SetFloat("_LabTime", animate ? fixedTime + Time.time : fixedTime); material.SetFloat("_ShowTexture", texture ? 1 : 0);
            }
        }
        void OnGUI() {
            GUILayout.BeginArea(new Rect(12, 12, 430, 210), GUI.skin.box);
            GUILayout.Label("ShaderLab: UV / vertex wave / dissolve (URP 17)");
            GUILayout.Label("Amount: " + amount.ToString("F2")); amount = GUILayout.HorizontalSlider(amount, 0, 1);
            GUILayout.Label("Fixed time: " + fixedTime.ToString("F2")); fixedTime = GUILayout.HorizontalSlider(fixedTime, 0, 20);
            animate = GUILayout.Toggle(animate, "Animate (uncheck for fixed-time comparison)");
            texture = GUILayout.Toggle(texture, "Texture instead of UV colors");
            GUILayout.Label("Teaching normals are not rebuilt after vertex displacement.");
            GUILayout.Label("No ShadowCaster / DepthOnly pass; disable depth priming.");
            GUILayout.EndArea();
        }
        void OnDestroy() {
            if (materials != null) foreach (Material material in materials) if (material != null) Destroy(material);
            if (checker != null) Destroy(checker);
        }
    }
}

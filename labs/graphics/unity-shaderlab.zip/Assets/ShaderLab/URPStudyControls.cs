using UnityEngine;
namespace ConceptLab.Graphics {
    public sealed class URPStudyControls : MonoBehaviour {
        public Material material;
        public Light mainLight;
        float amount = .35f;
        void OnGUI() {
            GUILayout.BeginArea(new Rect(12, 12, 420, 150), GUI.skin.box);
            GUILayout.Label("URP main light / Forward / ShadowCaster / DepthOnly");
            amount = GUILayout.HorizontalSlider(amount, 0, .8f);
            GUILayout.Label("Dissolve threshold: " + amount.ToString("F2"));
            if (material != null) material.SetFloat("_Amount", amount);
            if (mainLight != null && GUILayout.Button("Toggle main light shadows")) mainLight.shadows = mainLight.shadows == LightShadows.None ? LightShadows.Hard : LightShadows.None;
            GUILayout.Label("Use Frame Debugger; additional lights / GI / DepthNormals not implemented.");
            GUILayout.EndArea();
        }
    }
}

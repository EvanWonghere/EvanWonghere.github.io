// Original ConceptLab URP teaching shader. Not a full PBR / shadow-casting material.
Shader "ConceptLab/Dissolve" {
 Properties { _BaseColor("Color",Color)=(0.1,0.7,0.6,1) _MainTex("Checker (sRGB)",2D)="white"{} _Amount("Amount",Range(0,1))=0.4 _LabTime("Fixed Time",Float)=0 _ShowTexture("Show Texture",Float)=0 }
 SubShader {
  Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
  Pass {
   Name "Forward" Tags { "LightMode"="UniversalForward" }
   HLSLPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
   TEXTURE2D(_MainTex); SAMPLER(sampler_MainTex);
   CBUFFER_START(UnityPerMaterial)
   float4 _BaseColor; float4 _MainTex_ST; float _Amount; float _LabTime; float _ShowTexture;
   CBUFFER_END
   struct Attributes { float4 positionOS:POSITION; float3 normalOS:NORMAL; float2 uv:TEXCOORD0; };
   struct Varyings { float4 positionCS:SV_POSITION; float2 uv:TEXCOORD0; float3 normalWS:TEXCOORD1; float3 positionWS:TEXCOORD2; };
   Varyings vert(Attributes input) {
    Varyings o; float3 p=input.positionOS.xyz;
    // No vertex displacement in this lesson.
    o.positionCS=TransformObjectToHClip(p);
    o.positionWS=TransformObjectToWorld(p);
    o.normalWS=TransformObjectToWorldNormal(input.normalOS);
    o.uv=TRANSFORM_TEX(input.uv,_MainTex); return o;
   }
   float random2(float2 p) { return frac(sin(dot(p,float2(127.1,311.7)))*43758.5453); }
   float noise2(float2 p) { float2 i=floor(p),f=frac(p); f=f*f*(3-2*f); return lerp(lerp(random2(i),random2(i+float2(1,0)),f.x),lerp(random2(i+float2(0,1)),random2(i+float2(1,1)),f.x),f.y); }
   float fbm(float2 p) { float a=.5,n=0; [unroll] for(int i=0;i<4;i++){ n+=a*noise2(p);p=p*2+3.7;a*=.5;} return n; }
   half4 frag(Varyings input):SV_Target {
    float n=fbm(input.uv*7);
    clip(n-_Amount);
    float edge=1-smoothstep(_Amount,_Amount+.06,n);
    float3 N=normalize(input.normalWS),V=normalize(GetCameraPositionWS()-input.positionWS);
    float light=max(dot(N,normalize(float3(1,2,3))),0);
    float rim=pow(1-max(dot(N,V),0),3);
    float3 color=SAMPLE_TEXTURE2D(_MainTex,sampler_MainTex,input.uv).rgb*(.15+.85*light)+float3(1,.4,.08)*edge+float3(.1,.5,.6)*rim;
    return half4(color,1);
   }
   ENDHLSL
  }
 }
}

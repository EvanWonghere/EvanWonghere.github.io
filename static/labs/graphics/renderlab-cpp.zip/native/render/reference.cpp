#include <sstream>
// Original ConceptLab teaching rasterizer. No graphics or math dependencies.
// Column vectors; clip before divide; bottom-left coverage, top-left output.
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
using V3=std::array<double,3>;
using V4=std::array<double,4>;
using M=std::array<double,16>;
#ifdef RENDER_EXERCISE
#include "../work/render/exercises.hpp"
#endif
V3 sub(V3 a,V3 b) {
  return  {
    a[0]-b[0],a[1]-b[1],a[2]-b[2]
  };
}
double dot(V3 a,V3 b) {
  return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
}
V3 cross(V3 a,V3 b) {
  return  {
    a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]
  };
}
V3 unit(V3 a) {
  double n=std::sqrt(dot(a,a));
  if(n<1e-12)return  {
    0,0,0
  };
  for(auto&x:a)x/=n;
  return a;
}
V4 transform(M m,V4 v) {
#ifdef RENDER_EXERCISE
  return exercise::transform(m,v);
#else
  V4 r {
  };
  for(int i=0;i<4;i++)for(int k=0;k<4;k++)r[i]+=m[k*4+i]*v[k];
  return r;
#endif
}
M multiply(M a,M b) {
  M r {
  };
  for(int c=0;c<4;c++)for(int row=0;row<4;row++)for(int k=0;k<4;k++)r[c*4+row]+=a[k*4+row]*b[c*4+k];
  return r;
}
M perspective(double fov,double near,double far) {
  double f=1/std::tan(fov/2);
  return  {
    f,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0
  };
}
M lookAt(V3 eye,V3 target) {
  auto z=unit(sub(eye,target)),x=unit(cross( {
    0,1,0
  },z)),y=cross(z,x);
  return  {
    x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1
  };
}
M rotation(double angle) {
  double c=std::cos(angle),s=std::sin(angle);
  return  {
    c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1
  };
}
struct Vertex {
  V4 clip;
  V3 world,normal;
  std::array<double,2> uv;
};
Vertex mixVertex(Vertex a,Vertex b,double t) {
  Vertex r;

  for(int i=0;i<4;i++)r.clip[i]=a.clip[i]+(b.clip[i]-a.clip[i])*t;
  for(int i=0;i<3;i++) {
    r.world[i]=a.world[i]+(b.world[i]-a.world[i])*t;
    r.normal[i]=a.normal[i]+(b.normal[i]-a.normal[i])*t;
  }
  for(int i=0;i<2;i++)r.uv[i]=a.uv[i]+(b.uv[i]-a.uv[i])*t;
  return r;
}
using Tri=std::array<Vertex,3>;
double intersectionT(double da, double db) {
#ifdef RENDER_EXERCISE
  return exercise::intersectionT(da, db);
#else
  return da / (da - db);
#endif
}
std::vector<Tri> clipTriangle(Tri tri) {
  std::vector<Vertex> poly(tri.begin(),tri.end());
  for(int plane=0;plane<6;plane++) {
    std::vector<Vertex> next;
    auto distance=[&](V4 p) {
      return p[3]+(plane%2?-1:1)*p[plane/2];
    };
    for(size_t i=0;i<poly.size();i++) {
      auto a=poly[i],b=poly[(i+1)%poly.size()];
      double da=distance(a.clip),db=distance(b.clip);
      if(da>=0)next.push_back(a);
      if((da>=0)!=(db>=0))next.push_back(mixVertex(a,b,intersectionT(da,db)));
    }poly=next;
  }std::vector<Tri> out;
  for(size_t i=1;i+1<poly.size();i++)out.push_back( {
    poly[0],poly[i],poly[i+1]
  });
  return out;
}
double edge(V3 a,V3 b,V3 p) {
#ifdef RENDER_EXERCISE
  return exercise::edge(a,b,p);
#else
  return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);
#endif
}
bool topLeft(V3 a,V3 b) {
  return b[1]<a[1]||(b[1]==a[1]&&b[0]<a[0]);
}
double interpolate(V3 values,V3 w,V3 weights,bool correct) {
#ifdef RENDER_EXERCISE
  return exercise::interpolate(values,w,weights,correct);
#else
  double n=0,d=correct?0:1;
  for(int i=0;i<3;i++) {
    n+=weights[i]*values[i]/(correct?w[i]:1);
    if(correct)d+=weights[i]/w[i];
  }return n/d;
#endif
}
V3 checker(double u,double v,std::string filter) {
  auto texel=[](int x,int y)->V3 {
#ifdef RENDER_EXERCISE
    return exercise::texel(x,y);
#else
    int checker = (int(std::floor(x/4.))+int(std::floor(y/4.))) % 2;
    return (checker+2)%2 == 0 ? V3{.27,.31,.46} : V3{.88,.85,.78};
#endif
  };
  if(filter!="linear")return texel(int(std::floor(u*32)),int(std::floor(v*32)));
  double x=u*32-.5,y=v*32-.5,fx=x-std::floor(x),fy=y-std::floor(y);
  int ix=int(std::floor(x)),iy=int(std::floor(y));
  auto a=texel(ix,iy),b=texel(ix+1,iy),c=texel(ix,iy+1),d=texel(ix+1,iy+1);
  V3 r {
  };
  for(int i=0;i<3;i++)r[i]=(a[i]*(1-fx)+b[i]*fx)*(1-fy)+(c[i]*(1-fx)+d[i]*fx)*fy;
  return r;
}
struct Input {
  V3 position,normal;
  std::array<double,2> uv;
};
std::vector<std::array<Input,3>> parseOBJ(const std::string& path) {
  std::ifstream file(path);if(!file)throw std::runtime_error("Could not read OBJ");
  std::stringstream stream;stream<<file.rdbuf();std::string text=stream.str();
  if(text.size()>65536)throw std::runtime_error("OBJ exceeds 64 KiB");
  std::vector<V3> positions,normals;std::vector<std::array<double,2>> uvs;
  std::vector<std::array<Input,3>> out;
  auto index=[](const std::string& raw,size_t size){
    size_t used=0;int n=std::stoi(raw,&used);
    if(used!=raw.size()||n==0)throw std::runtime_error("OBJ index must be a nonzero integer");
    int i=n>0?n-1:int(size)+n;
    if(i<0||i>=int(size))throw std::runtime_error("OBJ index out of bounds");return i;
  };
  std::istringstream lines(text);std::string line;int lineNumber=0;
  while(std::getline(lines,line)){
    lineNumber++;line=line.substr(0,line.find('#'));std::istringstream row(line);std::string kind;row>>kind;if(kind.empty())continue;
    try{
      if(kind=="v"||kind=="vt"||kind=="vn"){
        std::vector<double> values;double x;while(row>>x){if(!std::isfinite(x))throw std::runtime_error("Non-finite OBJ attribute");values.push_back(x);}
        if(!row.eof()||values.size()!=(kind=="vt"?2u:3u))throw std::runtime_error("Unsupported OBJ attribute");
        if(kind=="v")positions.push_back({values[0],values[1],values[2]});
        else if(kind=="vt")uvs.push_back({values[0],values[1]});else normals.push_back(unit({values[0],values[1],values[2]}));
      }else if(kind=="f"){
        std::vector<Input> face;std::vector<bool> hasNormal;std::string token;
        while(row>>token){
          std::vector<std::string> ids;size_t start=0;
          for(;;){size_t slash=token.find('/',start);ids.push_back(token.substr(start,slash==std::string::npos?slash:slash-start));if(slash==std::string::npos)break;start=slash+1;}
          if(ids.size()>3)throw std::runtime_error("Unsupported OBJ face corner");
          V3 position=positions.at(index(ids[0],positions.size())),normal{0,0,0};std::array<double,2> uv{0,0};
          if(ids.size()>1&&!ids[1].empty())uv=uvs.at(index(ids[1],uvs.size()));
          bool normalFound=ids.size()>2&&!ids[2].empty();if(normalFound)normal=normals.at(index(ids[2],normals.size()));
          face.push_back({position,normal,uv});hasNormal.push_back(normalFound);
        }
        if(face.size()<3||face.size()>32)throw std::runtime_error("OBJ face requires 3-32 corners");
        for(size_t i=1;i+1<face.size();i++){
          std::array<Input,3> tri{face[0],face[i],face[i+1]};std::array<size_t,3> ids{0,i,i+1};
          V3 normal=unit(cross(sub(tri[1].position,tri[0].position),sub(tri[2].position,tri[0].position)));
          for(int j=0;j<3;j++)if(!hasNormal[ids[j]])tri[j].normal=normal;out.push_back(tri);
        }
      }else throw std::runtime_error("Unsupported OBJ statement: "+kind);
    }catch(const std::exception& error){throw std::runtime_error("OBJ line "+std::to_string(lineNumber)+": "+error.what());}
  }
  if(out.empty())throw std::runtime_error("OBJ has no faces");return out;
}
V3 sampleMip(double u,double v,double lod){
  static const auto levels=[](){
    std::vector<std::vector<V3>> result;
    for(int size=32;size>=1;size/=2){
      std::vector<V3> level;
      for(int y=0;y<size;y++)for(int x=0;x<size;x++){
        V3 value{};
        if(size==32)value=checker((x+.5)/32,(y+.5)/32,"nearest");
        else for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)for(int c=0;c<3;c++)value[c]+=result.back()[(y*2+dy)*size*2+x*2+dx][c]/4;
        level.push_back(value);
      }
      result.push_back(level);
    }return result;
  }();
  auto sample=[&](int l){
    int size=32/(1<<l);double x=u*size-.5,y=v*size-.5,fx=x-std::floor(x),fy=y-std::floor(y);int ix=int(std::floor(x)),iy=int(std::floor(y));
    auto texel=[&](int x,int y){return levels[l][((y%size+size)%size)*size+(x%size+size)%size];};
    auto a=texel(ix,iy),b=texel(ix+1,iy),c=texel(ix,iy+1),d=texel(ix+1,iy+1);V3 value{};
    for(int i=0;i<3;i++)value[i]=(a[i]*(1-fx)+b[i]*fx)*(1-fy)+(c[i]*(1-fx)+d[i]*fx)*fy;return value;
  };
  double l=std::clamp(lod,0.,5.),t=l-std::floor(l);auto a=sample(int(l)),b=sample(std::min(5,int(l)+1));V3 value{};
  for(int c=0;c<3;c++)value[c]=a[c]*(1-t)+b[c]*t;return value;
}
double shadowVisibility(const std::vector<double>& depth,int size,int x,int y,double z,double bias,const std::string& filter){
  int radius=filter=="pcf3"?1:0,blocked=0,count=0;
  for(int dy=-radius;dy<=radius;dy++)for(int dx=-radius;dx<=radius;dx++){
    int sx=x+dx,sy=y+dy;count++;
    if(sx<0||sy<0||sx>=size||sy>=size)continue;
#ifdef RENDER_EXERCISE
    blocked+=exercise::shadowed(z,depth[sy*size+sx],bias);
#else
    blocked+=z-bias>depth[sy*size+sx];
#endif
  }return 1-.75*double(blocked)/count;
}
std::vector<std::array<Input,3>> mesh(std::string scene,const std::string& modelPath="") {
  if(scene=="model")return parseOBJ(modelPath);
  std::vector<std::array<Input,3>> tris;
  if(scene=="triangle") {
    tris.push_back( {
      Input {
        {
          -.9,-.65,0
        }, {
          0,0,1
        }, {
          0,0
        }
      },Input {
        {
          .9,-.65,-1
        }, {
          0,0,1
        }, {
          1,0
        }
      },Input {
        {
          0,.9,0
        }, {
          0,0,1
        }, {
          .5,1
        }
      }
    });
    return tris;
  }
  auto quad=[&](std::array<V3,4> p,V3 n,double tiling=1) {
    std::array<std::array<double,2>,4> uv= {
      {
        {
          0,0
        }, {
          tiling,0
        }, {
          tiling,tiling
        }, {
          0,tiling
        }
      }
    };
    for(auto idx: {
      std::array<int,3> {
        0,1,2
      },std::array<int,3> {
        0,2,3
      }
    })tris.push_back( {
      Input {
        p[idx[0]],n,uv[idx[0]]
      },Input {
        p[idx[1]],n,uv[idx[1]]
      },Input {
        p[idx[2]],n,uv[idx[2]]
      }
    });
  };
  double s=.55;
  quad( {
    V3 {
      -s,-s,s
    }, {
      s,-s,s
    }, {
      s,s,s
    }, {
      -s,s,s
    }
  }, {
    0,0,1
  });
  quad( {
    V3 {
      s,-s,-s
    }, {
      -s,-s,-s
    }, {
      -s,s,-s
    }, {
      s,s,-s
    }
  }, {
    0,0,-1
  });
  quad( {
    V3 {
      s,-s,s
    }, {
      s,-s,-s
    }, {
      s,s,-s
    }, {
      s,s,s
    }
  }, {
    1,0,0
  });
  quad( {
    V3 {
      -s,-s,-s
    }, {
      -s,-s,s
    }, {
      -s,s,s
    }, {
      -s,s,-s
    }
  }, {
    -1,0,0
  });
  quad( {
    V3 {
      -s,s,s
    }, {
      s,s,s
    }, {
      s,s,-s
    }, {
      -s,s,-s
    }
  }, {
    0,1,0
  });
  quad( {
    V3 {
      -s,-s,-s
    }, {
      s,-s,-s
    }, {
      s,-s,s
    }, {
      -s,-s,s
    }
  }, {
    0,-1,0
  });
  quad( {
    V3 {
      -1.8,-.9,1.8
    }, {
      1.8,-.9,1.8
    }, {
      1.8,-.55,-1.8
    }, {
      -1.8,-.55,-1.8
    }
  }, {
    0,1,.0972
  },3);
  return tris;
}
struct Options {
  int size=128;
  double angle=25,distance=3;
  std::string scene="cube";
  bool clipping=true,depth=true,perspective=true,lighting=true,shadows=false;
  double bias=.005;
  bool cull=true;
  std::string filter="nearest";
  int probeX=64,probeY=64;
  double lod=0;
  std::string aa="none",shadowFilter="hard",modelPath;
};
struct Result {
  std::vector<unsigned char> pixels;
  std::vector<double> depth;
  int input=0,generated=0,covered=0,passed=0,visible=0,sampleSize=0,sampleCovered=0;
  bool hit=false;
  double z=0;
  V3 bary {
  },normal {
  };
  std::array<double,2> uv {
  };
};
Result rasterize(std::vector<Tri> triangles,Options o,M lightVP= {
},const Result* shadow=nullptr,bool shadowPass=false) {
  Result r;
  r.sampleSize=o.size;
  r.input=int(triangles.size());
  r.pixels.resize(o.size*o.size*3);
  r.depth.resize(o.size*o.size,1);
  for(int i=0;i<o.size*o.size;i++) {
    r.pixels[i*3]=8;
    r.pixels[i*3+1]=8;
    r.pixels[i*3+2]=11;
  }
  for(auto input:triangles)for(auto tri:o.clipping?clipTriangle(input):std::vector<Tri> {
    input
  }) {
    if(std::any_of(tri.begin(),tri.end(),[](Vertex v) {
      return v.clip[3]<=1e-8;
    }))continue;
    std::array<V3,3> screen {
    };
    for(int i=0;i<3;i++)screen[i]= {
      (tri[i].clip[0]/tri[i].clip[3]+1)*o.size/2,(tri[i].clip[1]/tri[i].clip[3]+1)*o.size/2,tri[i].clip[2]/tri[i].clip[3]
    };
    double area=edge(screen[0],screen[1],screen[2]);
    if(std::abs(area)<1e-10||(o.cull&&area<=0))continue;
    if(area<0) {
      std::swap(tri[1],tri[2]);
      std::swap(screen[1],screen[2]);
      area=-area;
    }r.generated++;
    int minX=std::max(0,int(std::ceil(std::min( {
      screen[0][0],screen[1][0],screen[2][0]
    })-.5))),maxX=std::min(o.size-1,int(std::floor(std::max( {
      screen[0][0],screen[1][0],screen[2][0]
    })-.5)));
    int minY=std::max(0,int(std::ceil(std::min( {
      screen[0][1],screen[1][1],screen[2][1]
    })-.5))),maxY=std::min(o.size-1,int(std::floor(std::max( {
      screen[0][1],screen[1][1],screen[2][1]
    })-.5)));
    for(int y=minY;y<=maxY;y++)for(int x=minX;x<=maxX;x++) {
      V3 p {
        double(x)+.5,double(y)+.5,0
      },e {
        edge(screen[1],screen[2],p),edge(screen[2],screen[0],p),edge(screen[0],screen[1],p)
      };
      bool outside=false;
      for(int i=0;i<3;i++)if(e[i]<0||(e[i]==0&&!topLeft(screen[(i+1)%3],screen[(i+2)%3])))outside=true;
      if(outside)continue;
      r.covered++;
      V3 b {
        e[0]/area,e[1]/area,e[2]/area
      };
      double z=(b[0]*screen[0][2]+b[1]*screen[1][2]+b[2]*screen[2][2]+1)/2;
      if(o.clipping&&(z<0||z>1))continue;
      int index=(o.size-1-y)*o.size+x;
#ifdef RENDER_EXERCISE
      if(o.depth&&!exercise::depthPass(z,r.depth[index]))continue;
#else
      if(o.depth&&z>=r.depth[index])continue;
#endif
      r.passed++;
      r.depth[index]=z;
      V3 w {
        tri[0].clip[3],tri[1].clip[3],tri[2].clip[3]
      };
      auto attr=[&](int key,int c) {
        V3 values {
        };
        for(int i=0;i<3;i++)values[i]=key==0?tri[i].world[c]:key==1?tri[i].normal[c]:tri[i].uv[c];
        return interpolate(values,w,b,o.perspective);
      };
      V3 world {
        attr(0,0),attr(0,1),attr(0,2)
      },normal=unit( {
        attr(1,0),attr(1,1),attr(1,2)
      });
      double u=attr(2,0),v=attr(2,1);
      V3 color=o.filter=="mip"?sampleMip(u,v,o.lod):checker(u,v,o.filter);
      double visibility=1;
      if(shadow) {
        auto q=transform(lightVP, {
          world[0],world[1],world[2],1
        });
        double nx=q[0]/q[3],ny=q[1]/q[3],nz=(q[2]/q[3]+1)/2;
        if(q[3]>0&&std::abs(nx)<1&&std::abs(ny)<1&&nz>=0&&nz<=1) {
          int sx=int(std::floor((nx+1)*o.size/2)),sy=o.size-1-int(std::floor((ny+1)*o.size/2));
          visibility=shadowVisibility(shadow->depth,o.size,sx,sy,nz,o.bias,o.shadowFilter);
        }
      }
      double diffuse=std::max(0.,dot(normal,unit(sub( {
        2,3,2
      },world))));
#ifdef RENDER_EXERCISE
      diffuse=exercise::lambert(normal,unit(sub( {
        2,3,2
      },world)));
#endif
      double intensity=o.lighting?.18+.82*diffuse*visibility:1;
      for(int c=0;c<3;c++)r.pixels[index*3+c]=shadowPass?0:static_cast<unsigned char>(std::lround(std::clamp(color[c]*intensity,0.,1.)*255));
      if(x==o.probeX&&o.size-1-y==o.probeY) {
        r.hit=true;
        r.z=z;
        r.bary=b;
        r.normal=normal;
        r.uv= {
          u,v
        };
      }
    }
  }r.visible=int(std::count_if(r.depth.begin(),r.depth.end(),[](double d) {
    return d<1;
  }));
  return r;
}
Result render(Options o) {
  if(o.aa=="ssaa2"){
    Options single=o;single.aa="none";auto base=render(single);
    single.size*=2;single.probeX*=2;single.probeY*=2;auto high=render(single);
    for(int y=0;y<o.size;y++)for(int x=0;x<o.size;x++)for(int c=0;c<3;c++){
      int sum=0;for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)sum+=high.pixels[((y*2+dy)*high.sampleSize+x*2+dx)*3+c];
      base.pixels[(y*o.size+x)*3+c]=static_cast<unsigned char>(std::lround(sum/4.));
    }
    base.sampleSize=high.sampleSize;base.sampleCovered=high.covered;return base;
  }
  double pi=std::acos(-1.);
  auto model=rotation(o.angle*pi/180),vp=multiply(perspective(pi/3,.3,20),lookAt( {
    0,.6,o.distance
  }, {
    0,-.1,0
  }));
  std::vector<Tri> vertices;
  for(auto tri:mesh(o.scene,o.modelPath)) {
    Tri t {
    };
    for(int i=0;i<3;i++) {
      auto v=tri[i];
      auto p=transform(model, {
        v.position[0],v.position[1],v.position[2],1
      }),n=transform(model, {
        v.normal[0],v.normal[1],v.normal[2],0
      });
      t[i]= {
        transform(vp,p), {
          p[0],p[1],p[2]
        },unit( {
          n[0],n[1],n[2]
        }),v.uv
      };
    }vertices.push_back(t);
  }auto lightVP=multiply(perspective(pi/2,.3,15),lookAt( {
    2,3,2
  }, {
    0,0,0
  }));
  Result shadow;
  if(o.shadows) {
    auto lightVertices=vertices;
    for(auto&tri:lightVertices)for(auto&v:tri)v.clip=transform(lightVP, {
      v.world[0],v.world[1],v.world[2],1
    });
    Options so=o;
    so.clipping=true;
    so.depth=true;
    so.cull=false;
    so.perspective=true;
    shadow=rasterize(lightVertices,so, {
    },nullptr,true);
  }return rasterize(vertices,o,lightVP,o.shadows?&shadow:nullptr);
}
int selfTest() {
  int failed=0;
  auto check=[&](bool ok,const char* name) {
    std::cerr<<(ok?"PASS ":"FAIL ")<<name<<"\n";
    failed+=!ok;
  };
  M id {
    1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1
  };
  check(transform(id, {
    1,2,3,1
  })==V4 {
    1,2,3,1
  },"coordinates");
  Vertex a {
    {
      -.2,0,-2,1
    }, {
      0,0,0
    }, {
      0,0,1
    }, {
      0,0
    }
  },b {
    {
      .8,-.8,0,1
    }, {
      0,0,0
    }, {
      0,0,1
    }, {
      1,0
    }
  },c {
    {
      0,.8,0,1
    }, {
      0,0,0
    }, {
      0,0,1
    }, {
      0,1
    }
  };
  auto clipped=clipTriangle( {
    a,b,c
  });
  check(clipped.size()==2&&std::all_of(clipped.begin(),clipped.end(),[](Tri t) {
    return std::all_of(t.begin(),t.end(),[](Vertex v) {
      return v.clip[2]>=-v.clip[3]-1e-10;
    });
  }),"clipping");
  check(edge( {
    0,0,0
  }, {
    1,0,0
  }, {
    0,1,0
  })==1,"coverage");
  Options o;
  auto r=render(o);
  check(r.visible>0&&r.hit&&r.z<1,"depth");
  check(std::abs(interpolate( {
    0,1,0
  }, {
    1,2,1
  }, {
    .25,.5,.25
  },true)-1./3)<1e-10,"interpolation");
  check(checker(0,0,"nearest")[1]==.31,"sampling");
  check(dot(unit( {
    0,0,2
  }),unit( {
    0,0,1
  }))==1,"normal");
  o.shadows=true;
  auto shadowed=render(o);
  check(shadowed.depth==r.depth&&shadowed.pixels!=r.pixels,"two-pass shadows on sloped receiver");
  return failed?1:0;
}
int main(int argc,char**argv) {
  try {
    if(argc==2&&std::string(argv[1])=="--self-test")return selfTest();
    if(argc!=17&&argc!=21)throw std::runtime_error("Use run.py; expected 16 or 20 arguments");
    Options o;
    o.size=std::stoi(argv[1]);
    o.angle=std::stod(argv[2]);
    o.distance=std::stod(argv[3]);
    o.scene=argv[4];
    o.clipping=std::stoi(argv[5]);
    o.depth=std::stoi(argv[6]);
    o.perspective=std::stoi(argv[7]);
    o.lighting=std::stoi(argv[8]);
    o.shadows=std::stoi(argv[9]);
    o.bias=std::stod(argv[10]);
    o.cull=std::stoi(argv[11]);
    o.filter=argv[12];
    o.probeX=std::stoi(argv[13]);
    o.probeY=std::stoi(argv[14]);
    if(argc==21){o.lod=std::stod(argv[17]);o.aa=argv[18];o.shadowFilter=argv[19];o.modelPath=argv[20];}
    if(!std::isfinite(o.lod)||o.lod<0||o.lod>5||(o.aa!="none"&&o.aa!="ssaa2")||(o.shadowFilter!="hard"&&o.shadowFilter!="pcf3"))throw std::runtime_error("Invalid application options");
    if(o.size<32||o.size>384||!std::isfinite(o.angle)||!std::isfinite(o.distance)||o.distance<.35||o.distance>6||!std::isfinite(o.bias))throw std::runtime_error("Invalid bounded inputs");
    auto r=render(o);
    std::ofstream image(argv[15],std::ios::binary);
    image<<"P6\n"<<o.size<<" "<<o.size<<"\n255\n";
    image.write(reinterpret_cast<char*>(r.pixels.data()),std::streamsize(r.pixels.size()));
    if(!image)throw std::runtime_error("Could not write PPM");
    std::ofstream depth(argv[16],std::ios::binary);
    depth.write(reinterpret_cast<char*>(r.depth.data()),std::streamsize(r.depth.size()*sizeof(double)));
    if(!depth)throw std::runtime_error("Could not write depth");
    std::cout<<std::setprecision(17)<<"{\"inputTriangles\":"<<r.input<<",\"rasterTriangles\":"<<r.generated<<",\"coveredSamples\":"<<r.covered<<",\"depthPassed\":"<<r.passed<<",\"visiblePixels\":"<<r.visible<<",\"probe_hit\":"<<(r.hit?"true":"false");
    if(r.hit)std::cout<<",\"probe_depth\":"<<r.z<<",\"probe_b0\":"<<r.bary[0]<<",\"probe_b1\":"<<r.bary[1]<<",\"probe_b2\":"<<r.bary[2]<<",\"probe_u\":"<<r.uv[0]<<",\"probe_v\":"<<r.uv[1]<<",\"probe_normalX\":"<<r.normal[0]<<",\"probe_normalY\":"<<r.normal[1]<<",\"probe_normalZ\":"<<r.normal[2];
    if(o.aa=="ssaa2")std::cout<<",\"sampleResolution\":"<<r.sampleSize<<",\"sampleCoveredSamples\":"<<r.sampleCovered<<",\"resolvedPixels\":"<<o.size*o.size;
    std::cout<<"}\n";
    return 0;
  }catch(const std::exception&e) {
    std::cerr<<e.what()<<"\n";
    return 1;
  }
}

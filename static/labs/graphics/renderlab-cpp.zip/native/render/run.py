#!/usr/bin/env python3
"""Compile local C++ reference/exercises; images never leave this machine."""
import argparse, datetime, hashlib, json, pathlib, platform, shutil, subprocess, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--lab',default='raster-project');p.add_argument('--mode',choices=['default','exercise','affine','depth-off','clip-off'],default='default');p.add_argument('--param',action='append',default=[]);p.add_argument('--model');p.add_argument('--output');p.add_argument('--check',action='store_true');args=p.parse_args()
catalog=json.loads((ROOT.parent/'src/catalog.json').read_text());lab=next((l for l in catalog if l['id']==args.lab and l.get('workspace')=='raster'),None)
if not lab:p.error('Use a raster-* experiment ID')
params={c['key']:c['value'] for c in lab['controls']}
for pair in args.param:
 key,sep,value=pair.partition('=')
 if not sep or key not in params:p.error('Unknown parameter; use key=value')
 try:params[key]=json.loads(value)
 except json.JSONDecodeError:params[key]=value
for c in lab['controls']:
 value=params[c['key']]
 if c['type']=='checkbox' and not isinstance(value,bool):p.error('Boolean parameter required')
 if c['type']=='select' and value not in c['options']:p.error('Unknown select value')
 if c['type']=='range' and (isinstance(value,bool) or not isinstance(value,(int,float)) or not c['min']<=value<=c['max']):p.error('Numeric parameter outside bounds')
if args.mode=='affine':params['perspective']=False
if args.mode=='depth-off':params['depth']=False
if args.mode=='clip-off':params['clip']=False
out=pathlib.Path(args.output) if args.output else ROOT/'results';out.mkdir(parents=True,exist_ok=True)
compiler=shutil.which('clang++') or shutil.which('g++')
if not compiler:raise SystemExit('C++20 compiler unavailable')
source=ROOT/'render/reference.cpp';exe=out/('render-exercise' if args.mode=='exercise' else 'render-reference')
command=[compiler,'-std=c++20','-O2','-Wall','-Wextra',str(source),'-o',str(exe)]
if args.mode=='exercise':command.insert(1,'-DRENDER_EXERCISE')
subprocess.run(command,check=True)
if args.check:subprocess.run([str(exe),'--self-test'],check=True)
image=out/f'{args.lab}-{args.mode}.ppm';depth=out/f'{args.lab}-{args.mode}.depth'
keys=['resolution','angle','distance','scene','clip','depth','perspective','lighting','shadows','bias','cull','filter','probeX','probeY']
values=[str(int(params[k])) if isinstance(params[k],bool) else str(params[k]) for k in keys]
model=pathlib.Path(args.model).resolve() if args.model else ROOT.parent/'src/graphics/house.obj'
if params['scene']=='model' and (not model.is_file() or model.stat().st_size>65536):p.error('OBJ must be a local file at most 64 KiB')
application_values = [str(params.get('lod',0)),str(params.get('aa','none')),str(params.get('shadowFilter','hard')),str(model)]
start=time.perf_counter();metrics=json.loads(subprocess.check_output([str(exe),*values,str(image),str(depth),*application_values],text=True));metrics['processMilliseconds']=(time.perf_counter()-start)*1000
checks=[{'label':'native output contains finite visible geometry', 'passed':metrics['visiblePixels']>0}]
source_bytes=source.read_bytes()+(ROOT/'work/render/exercises.hpp').read_bytes() if args.mode=='exercise' else source.read_bytes()
obs={'schemaVersion':1,'labId':lab['id'],'labVersion':lab['version'],'source':'native','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'runtime':'C++20 CPU software rasterizer','compiler':subprocess.check_output([compiler,'--version'],text=True).splitlines()[0],'os':platform.platform(),'architecture':platform.machine(),'sourceDigest':hashlib.sha256(source_bytes).hexdigest(),'mode':args.mode,'optimization':'O2'},'parameters':params,'metrics':metrics,'events':['compiled local C++ source','wrote local PPM and float64 depth buffer','process time includes startup and file IO; not GPU time'],'checks':checks}
if params['scene']=='model':obs['environment']['modelDigest']=hashlib.sha256(model.read_bytes()).hexdigest();obs['events'].append('loaded local OBJ; convex polygons only; no MTL')
path=out/f'{args.lab}-{args.mode}.json';path.write_text(json.dumps(obs,ensure_ascii=False,indent=2)+'\n');print(path)
if not all(c['passed'] for c in checks):raise SystemExit('Exercise produced no visible geometry; JSON retained for investigation')

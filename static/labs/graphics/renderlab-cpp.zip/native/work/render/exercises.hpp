#pragma once
// Fill one TODO at a time; run --mode exercise to compile this file.
// Reference implementation is separate in native/render/reference.cpp.
namespace exercise {
inline V4 transform(M, V4) { // 1. Column-major matrix times column vector.
  return {0,0,0,0};
}
inline double intersectionT(double, double) { // 2. Compute da/(da-db).
  return 0;
}
inline double edge(V3,V3,V3) { // 3. Signed 2D edge function.
  return 0;
}
inline bool depthPass(double,double) { // 4. LESS depth convention.
  return false;
}
inline double interpolate(V3,V3,V3,bool) { // 5. Perspective denominator.
  return 0;
}
inline V3 texel(int, int) { // 6. Repeat-wrapped checker texel (4x4 blocks).
  return {0,0,0};
}
inline double lambert(V3,V3) { // 7. Normalized world-space vectors.
  return 0;
}
inline bool shadowed(double,double,double) { // 8. Light-space depth and bias.
  return false;
}
}

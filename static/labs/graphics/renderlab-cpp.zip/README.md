# RenderLab C++20 练习

从软件光栅化解释 GPU 管线，参考 TinyRenderer 作者课程：<https://haqr.eu/tinyrenderer/>。本包实现为 ConceptLab 编写，无第三方图形／数学库，也不携带教程模型和纹理。

在解压根目录运行：

```sh
python3 native/render/run.py --lab raster-project --check
python3 native/render/run.py --lab raster-interpolation --mode affine
python3 native/render/run.py --lab raster-shadows --param bias=0
python3 native/render/run.py --lab raster-project --mode exercise
```

需要 Python 3 与 C++20 编译器（clang++ 或 g++）。参考代码在 `native/render/reference.cpp`，你的练习在 `native/work/render/exercises.hpp`。不要覆盖参考实现。`exercise` 起始实现有意不完整：失败和导出空画面并不表示安装失败，逐个完成 TODO 再运行。

八个阶段：矩阵向量乘法、裁剪交点、边函数、深度比较、透视插值、纹理采样、漫反射、阴影比较。第八课将它们整合成软件渲染器，再加入至少三个错误／修复的可复现案例。

输出默认在 `native/results/`：PPM 画面、float64 深度文件和观测 JSON。网页导入 JSON；来源标签不是认证签名。PPM 可用常见图像软件打开。本包的 `processMilliseconds` 包含进程启动与文件 IO，不是 GPU 耗时；只可与同一环境的同类运行比较。

参数与网页一致，可通过 `--param key=value` 修改，布尔值使用 true / false。坐标为列向量、OpenGL 六平面裁剪；深度较小更近；覆盖使用像素中心和 top-left 规则。输出层单独翻转 Y。场景含倾斜接收面，检查 bias 太小的 acne 与太大的阴影脱离。首版是单采样硬阴影，没有 PCF。

运行 `--check` 只检验参考实现的有限算法场景，不代表你独立掌握。记录你的源码、环境、参数和解释。

## 应用课程

新增六课对应 OBJ、背面剔除、显式 mip LOD、SSAA、3×3 PCF 和综合项目。

```sh
python3 native/render/run.py --lab raster-model
python3 native/render/run.py --lab raster-model --model src/graphics/house.obj
python3 native/render/run.py --lab raster-lod --param lod=3.5
python3 native/render/run.py --lab raster-aa --param aa=ssaa2
python3 native/render/run.py --lab raster-pcf --param shadowFilter=pcf3
python3 native/render/run.py --lab raster-engine --check
```

`src/graphics/house.obj` 为本批独立编写的小房子凸模型（CC0），没有上游模型。`--model` 只读取本地文件，最多 64 KiB；支持 v/vt/vn、正负索引、凸多边形扇形三角化。拒绝索引 0、越界、非有限属性与不支持语句。缺 UV 使用 (0,0)，缺法线使用面法线；不支持 MTL、凹多边形、骨骼和曲面。观测包含实际文件 SHA-256；修改模型后不能再声称与网页内置模型是同一输入。

`filter=mip` 使用 32→16→8→4→2→1 的 box 预滤波链、层内双线性与层间插值。LOD 为手动教学参数，没有自动导数 footprint 或各向异性。纹理数值按线性教学值处理。

`aa=ssaa2` 用两倍宽高实际渲染并 2×2 平均颜色，输出仍为指定尺寸。深度、UV、法线和 probe 保留中心样本诊断；sampleResolution/sampleCoveredSamples 标明实际彩色采样层。它不是硬件 MSAA。

`shadowFilter=pcf3` 先比较九个深度再平均遮挡比例，越界样本按不遮挡。核尺寸固定，不是 PCSS 或级联；偏移和倾斜接收面误差仍需独立解释。参考实现支持这些功能；`exercises.hpp` 保留最小八阶段 TODO，扩展功能应在完成基础后自行改写实现。
